package org.example;
import org.example.Util.*;
import org.example.dao.ConteudoRepository;
import org.example.dao.*;
import org.example.bd.ConnectionFactory;

import java.sql.Connection;

public class Main {
    public static void main(String[] args) {
        Usuario joao = new Usuario("joao12345");
        Usuario maria = new Usuario("maria02");
        Usuario valen = new Usuario("valen1");
        Usuario homura = new Usuario("homura_akemi");
        Usuario ana = new Usuario("ana_costa");
        Usuario lucas = new Usuario("lucas_martins");
        Usuario julia = new Usuario("julia_ferreira");
        Usuario bruno = new Usuario("bruno_almeida");
        Usuario carla = new Usuario("carla_pereira");
        Usuario rafael = new Usuario("rafael_rodrigues");
        Usuario laura = new Usuario("laura_barbosa");
        Usuario isabella = new Usuario("isaboni");

        Filme matrix = new Filme("Matrix", 1999, "Diretor", 10, 120);
        Filme interestelar = new Filme("Interestelar", 2014, "Christopher Nolan", 12, 169);
        Filme origem = new Filme("A Origem", 2010, "Christopher Nolan", 14, 148);
        Filme avatar = new Filme("Avatar", 2009, "James Cameron", 12, 162);
        Filme gladiador = new Filme("Gladiador", 2000, "Ridley Scott", 16, 155);
        Filme parasita = new Filme("Parasita", 2019, "Bong Joon-ho", 16, 132);
        Filme corra = new Filme("Corra!", 2017, "Jordan Peele", 16, 104);
        Filme bastardos = new Filme("Bastardos Inglórios", 2009, "Quentin Tarantino", 18, 153);
        Filme dunas = new Filme("Duna", 2021, "Denis Villeneuve", 14, 155);
        Filme clubeDaLuta = new Filme("Clube da Luta", 1999, "David Fincher", 18, 139);


        Serie madoka = new Serie("Madoka", 2011, "Diretor2", 14, 12);
        Serie breakingBad = new Serie("Breaking Bad", 2008, "Vince Gilligan", 18, 62);
        Serie strangerThings = new Serie("Stranger Things", 2016, "Duffer Brothers", 14, 34);
        Serie theOffice = new Serie("The Office", 2005, "Greg Daniels", 12, 201);
        Serie dark = new Serie("Dark", 2017, "Baran bo Odar", 16, 26);
        Serie wkwkwkw = new Serie("wkwkwkw", 2019, "Eric Kripke", 18, 24);


        Genero ficcao = new Genero("Ficção Científica");
        Genero acao = new Genero("Ação");
        Genero fantasia = new Genero("Fantasia");
        Genero drama = new Genero("Drama");
        Genero comedia = new Genero("Comédia");
        Genero suspense = new Genero("Suspense");
        Genero terror = new Genero("Terror");
        Genero romance = new Genero("Romance");
        Genero documentario = new Genero("Documentário");
        Genero aventura = new Genero("Aventura");
        Genero animacao = new Genero("Animação");
        Genero musical = new Genero("Musical");
        Genero policial = new Genero("Policial");
        Genero guerra = new Genero("Guerra");


        homura.seguirUsuario(valen);
        ana.seguirUsuario(lucas);
        ana.seguirUsuario(julia);

        lucas.seguirUsuario(bruno);
        lucas.seguirUsuario(rafael);

        julia.seguirUsuario(carla);
        julia.seguirUsuario(rafael);
        julia.seguirUsuario(laura);
        bruno.seguirUsuario(laura);
        bruno.seguirUsuario(ana);
        carla.seguirUsuario(lucas);
        rafael.seguirUsuario(laura);

        laura.seguirUsuario(ana);
        valen.listarSeguidores();
        laura.listarSeguidores();

        homura.exibirReviewsUsuario();
        fantasia.adicionarConteudo(madoka);
        fantasia.listarConteudo();

        madoka.exibirInfo();
        acao.adicionarConteudo(matrix);
        fantasia.adicionarConteudo(madoka);


        matrix.adicionarGenero(acao);
        madoka.adicionarGenero(fantasia);


        joao.adicionarFavorito(matrix);
        joao.adicionarFavorito(madoka);


        System.out.println("Favoritos de João:");
        joao.listarFavoritos();


        joao.seguirUsuario(maria);


        System.out.println("Seguidores de Maria:");
        maria.listarSeguidores();


        Review review1 = new Review(joao, matrix, 8.5f, "Muito bom", "Gostei bastante do filme.");
        Review review2 = new Review(ana, matrix, 9.0f, "Excelente!", "Visual e roteiro incríveis.");
        Review review3 = new Review(lucas, madoka, 7.5f, "Interessante", "A série tem bons momentos, mas podia ser melhor.");
        Review review4 = new Review(julia, madoka, 8.0f, "Gostei", "Boa série, ótima para maratonar.");
        Review review5 = new Review(bruno, matrix, 6.0f, "Regular", "Esperava mais ação.");
        Review review6 = new Review(carla, madoka, 9.5f, "Fantástica!", "Personagens cativantes e enredo envolvente.");
        Review review7 = new Review(rafael, matrix, 7.0f, "Bom", "Vale a pena assistir, mas com ressalvas.");
        Review review8 = new Review(laura, madoka, 8.8f, "Recomendo", "Muito bem produzida, gostei bastante.");
        Review review9 = new Review(joao, madoka, 8.5f, "Muito bom", "Gostei bastante do filme.");
        Review review10 = new Review(homura, madoka, 8.5f, "Muito bom", "Gostei bastante do filme.");
        Review review15 = new Review(isabella, wkwkwkw, 8.5f, "Muito bom", "Gostei bastante do filme.");


        ana.adicionarReview(review2);
        lucas.adicionarReview(review3);
        julia.adicionarReview(review4);
        bruno.adicionarReview(review5);
        carla.adicionarReview(review6);
        rafael.adicionarReview(review7);
        laura.adicionarReview(review8);
        joao.adicionarReview(review1);
        joao.adicionarReview(review2);
        joao.adicionarReview(review9);
        joao.exibirReviewsUsuario();
        ana.adicionarReview(review2);
        ana.exibirReviewsUsuario();
        isabella.adicionarReview(review15);


        matrix.listarGeneros();

        fantasia.listarConteudo();
        ConnectionFactory fabricaDeConexao = new ConnectionFactory();
        Connection connection = fabricaDeConexao.recuperaConexao();

        UsuarioDAO udao =new UsuarioDAO(connection);
        GeneroDAO gdao = new GeneroDAO(connection);
        ReviewDAO rdao = new ReviewDAO(connection);
        SerieDAO sdao = new SerieDAO(connection);
        FilmeDAO fdao = new FilmeDAO(connection);
        ConteudoRepository cdao = new ConteudoRepository(connection);


        System.out.println(fdao.buscarPorId(180));
        System.out.println(udao.buscarPorId(19));
        System.out.println(udao.listarConteudosDoUsuario(19));
        System.out.println(udao.listarTodosEagerLoading());
        System.out.println(fdao.listarTodosEagerLoading());
        System.out.println(sdao.listarTodosEagerLoading());
        System.out.println(gdao.listarTodosEagerLoading());
        System.out.println(rdao.listarTodosEagerLoading());
        System.out.println(udao.listarUsuariosCom1Conteudo());
        System.out.println(udao.listarUsuarios2seguidores());





    }

}





